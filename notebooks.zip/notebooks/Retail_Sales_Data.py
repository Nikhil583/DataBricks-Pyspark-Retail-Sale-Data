# Databricks notebook source
# DBTITLE 1,Create Database
# MAGIC %sql
# MAGIC CREATE DATABASE if not exists b2bdatahub_catalog_dev.pysparkProject

# COMMAND ----------

# DBTITLE 1,Create Volume to Store Raw File
# MAGIC %sql
# MAGIC CREATE VOLUME if not exists b2bdatahub_catalog_dev.pysparkproject.bronze

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME if not exists b2bdatahub_catalog_dev.pysparkproject.silver

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME if not exists b2bdatahub_catalog_dev.pysparkproject.gold

# COMMAND ----------

# MAGIC %md
# MAGIC # Ingestion: Data Added to Bronze Layer

# COMMAND ----------

# DBTITLE 1,read bronze file
raw_order = spark.read.csv("/Volumes/b2bdatahub_catalog_dev/pysparkproject/bronze/retail_dataset.csv",header=True,inferSchema=True)
display(raw_order)

# COMMAND ----------

raw_customer = spark.read.json("/Volumes/b2bdatahub_catalog_dev/pysparkproject/bronze/customer_dataset.json")
display(raw_customer)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation: Bronze To Silver

# COMMAND ----------

raw_order.printSchema()

# COMMAND ----------

display(raw_order.head(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema Evaluation and fixing for Order Table

# COMMAND ----------

# DBTITLE 1,Silver Order
from pyspark.sql.functions import *

order_ts= coalesce(
    to_timestamp(trim(col("order_date")),"MM-dd-yyyy"),
    to_timestamp(trim(col("order_date")),"yyyy-MM-dd"),
    to_timestamp(trim(col("order_date")),"dd/MM/yyyy"),
    to_timestamp(trim(col("order_date")),"d-MMM-yyyy"),
    to_timestamp(trim(col("order_date")),"dd-MM-yyyy")
)

stg_order = (
    raw_order
    .withColumn("order_id", trim(col("order_id")).cast("Long"))
    .withColumn("order_date_ts", order_ts)
    .drop("order_date")
    .withColumn("customer_id", trim(col("customer_id")))
    .withColumn("customer_name", trim(col("customer_name")))
    .withColumn("product_id", trim(col("product_id")))
    .withColumn("product_name", lower(trim(col("product_name"))))
    .withColumn("category", lower(trim(col("category"))))
    .withColumn("quantity", trim(col("quantity")).cast("int"))
    .withColumn("quantity", when((col("quantity").isNull()) | (col("quantity") == "") | (col("quantity") < 1), lit(1)).otherwise(col("quantity")))
    .withColumn("price", trim(translate(col("price"),"$,", "")).cast("double"))
    .withColumn("payment_type", lower(trim(col("payment_type"))))
    .withColumn("order_status", lower(trim(col("order_status"))))
    .withColumn("returned", lower(trim(col("returned"))))
    .withColumn("total_amount", round((col("quantity") * col("price")), 2).cast("double")))

stg_order = stg_order.dropDuplicates(["order_id","product_id"]).filter(col("order_status").isNotNull() & (col("product_id") != "null"))
    

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write Table to Silver Layer

# COMMAND ----------

stg_order.write.format("delta").mode("overwrite").saveAsTable("b2bdatahub_catalog_dev.pysparkproject.stg_silver_order")


# COMMAND ----------

# Write the staged order dataframe to Parquet in the specified workspace directory
stg_order.write.format("parquet") \
    .mode("overwrite") \
    .save("/Volumes/b2bdatahub_catalog_dev/pysparkproject/silver/order")

# COMMAND ----------

raw_customer.printSchema()

# COMMAND ----------

display(raw_customer.head(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema Evaluation and fixing for Customer Table

# COMMAND ----------

from pyspark.sql.functions import *

signup_ts= coalesce(
    to_timestamp(trim(col("signup_date")),"MM-dd-yyyy"),
    to_timestamp(trim(col("signup_date")),"yyyy-MM-dd"),
    to_timestamp(trim(col("signup_date")),"dd/MM/yyyy"),
    to_timestamp(trim(col("signup_date")),"d-MMM-yyyy"),
    to_timestamp(trim(col("signup_date")),"dd-MM-yyyy")
)

stg_customer = (
    raw_customer
    .withColumn("customer_id", trim(col("customer_id")))
    .withColumn("city", lower(trim(col("city"))))
    .withColumn("age", when(trim(col("age")).isNull() | (trim(col("age"))=="") | (trim(col("age")).cast("int")<0), None).otherwise(trim(col("age")).cast("int")))
    .withColumn("gender", lower(trim(col("gender"))))
    .withColumn("loyalty_tier", lower(trim(col("loyalty_tier"))))
    .withColumn("signup_date_ts", signup_ts)
    .drop("signup_date")
    .dropDuplicates(["customer_id"])
)

# COMMAND ----------

stg_customer.printSchema()

# COMMAND ----------

xstg_customer = stg_customer.withColumn(
    "gender",
    when(col("gender").isNull(), None)
    .otherwise(
        when(col("gender").isin("male", "m"), lit("m"))
        .otherwise(when(col("gender").isin("female", "f"), lit("f")))
    )
)

# COMMAND ----------

stg_customer = stg_customer.withColumn(
    "loyalty_tier",
    when(col("loyalty_tier").isNull(), None)
    .otherwise(col("loyalty_tier"))
)

# COMMAND ----------

display(stg_customer)
stg_customer.write.format("delta").mode("overwrite").saveAsTable("b2bdatahub_catalog_dev.pysparkproject.stg_silver_customer")

# COMMAND ----------

stg_customer.write.format("parquet") \
    .mode("overwrite") \
    .save("/Volumes/b2bdatahub_catalog_dev/pysparkproject/silver/customer")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from b2bdatahub_catalog_dev.pysparkproject.stg_silver_customer

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Layer 

# COMMAND ----------

silver_order = spark.table("b2bdatahub_catalog_dev.pysparkproject.stg_silver_order")
silver_customer = spark.table("b2bdatahub_catalog_dev.pysparkproject.stg_silver_customer")

# COMMAND ----------

retail_details = silver_order.join(silver_customer, on='customer_id', how= "left")

retail_details = retail_details.withColumn("order_date_ts", to_date(col("order_date_ts"))).withColumn("year",year(col('order_date_ts'))).withColumn("month",month(col('order_date_ts')))

# COMMAND ----------

from pyspark.sql.functions import *

gold_df = (
    retail_details
    .groupBy("product_id","product_name","customer_id","category","year","month","order_date_ts","gender","age","city","loyalty_tier")
    .agg(
        sum(coalesce(col("quantity"),lit(0))).alias("total_quantity"),
        sum(col("total_amount")).alias("total_sales"),
        countDistinct(col("order_id")).alias("total_orders"),
        min(col("price")).alias("min_price"),
        max(col("price")).alias("max_price"),
        avg(col("price")).alias("avg_price"),
        sum(when(col("returned") == "yes",1).otherwise(lit(0))).alias("return_count"),
        sum(when(col("returned") == "yes",col("total_amount")).otherwise(0.0)).alias("total_return_amount"))
)

gold_df = gold_df.withColumn("avg_order_value", when(col("total_orders")>0, col("total_sales")/col("total_orders")).otherwise(lit(0.0)))
gold_df = gold_df.withColumn("avg_price_per_item", when(col("total_quantity")>0, col("total_sales")/col("total_quantity")).otherwise(lit(0.0))).withColumn("refreshed_at",current_timestamp())

display(gold_df)

# COMMAND ----------

gold_df.write.format("delta").mode("overwrite").saveAsTable("b2bdatahub_catalog_dev.pysparkproject.gold_retail_data")

# COMMAND ----------

gold_df.write.format("parquet") \
    .mode("overwrite") \
    .save("/Volumes/b2bdatahub_catalog_dev/pysparkproject/gold/retail_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME IF NOT EXISTS b2bdatahub_catalog_dev.pysparkproject.notebooks

# COMMAND ----------

